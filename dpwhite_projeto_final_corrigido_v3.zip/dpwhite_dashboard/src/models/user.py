from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)  # 'pme', 'adesao', 'individual', 'familiar', 'admin'
    name = db.Column(db.String(100), nullable=True)
    
    # Relationship with proposals
    proposals = db.relationship('Proposal', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @staticmethod
    def create_default_users():
        """Create default users if they don't exist"""
        default_users = [
            {'email': 'pme@gmail.com', 'password': '123456', 'user_type': 'pme', 'name': 'Usuário PME'},
            {'email': 'adesao@gmail.com', 'password': '123456', 'user_type': 'adesao', 'name': 'Usuário Adesão'},
            {'email': 'individual@gmail.com', 'password': '123456', 'user_type': 'individual', 'name': 'Usuário Individual'},
            {'email': 'familiar@gmail.com', 'password': '123456', 'user_type': 'familiar', 'name': 'Usuário Familiar'},
            {'email': 'Admconferencia@gmail.com', 'password': '123456', 'user_type': 'admin', 'name': 'Administrador'},
            {'email': 'corretor@gmail.com', 'password': '123456', 'user_type': 'corretor', 'name': 'Corretor'}
        ]
        
        for user_data in default_users:
            existing_user = User.query.filter_by(email=user_data['email']).first()
            if not existing_user:
                user = User(
                    email=user_data['email'],
                    user_type=user_data['user_type'],
                    name=user_data['name']
                )
                user.set_password(user_data['password'])
                db.session.add(user)
        
        db.session.commit()

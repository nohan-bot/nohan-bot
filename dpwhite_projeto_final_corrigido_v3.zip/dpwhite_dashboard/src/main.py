import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, render_template, send_from_directory, session, redirect, url_for, abort
from src.models.user import db, User
from src.routes.auth import auth_bp
from src.routes.proposals import proposals_bp
import os

# Define the base directory for the dpwhite_app
DPWHITE_APP_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'dpwhite_app'))

app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['SECRET_KEY'] = 'dpwhite-dashboard-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db.init_app(app)

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(proposals_bp)

# Create database tables
with app.app_context():
    db.create_all()
    # Create default users
    User.create_default_users()

# Serve static files for the dashboard (from src/static)
@app.route('/static/<path:path>')
def serve_dashboard_static(path):
    return send_from_directory('static', path)

# Serve static files for the dpwhite_app (from dpwhite_app/assets)
@app.route('/assets/<path:path>')
def serve_dpwhite_app_assets(path):
    return send_from_directory(os.path.join(DPWHITE_APP_DIR, 'assets'), path)

# Serve uploaded files
@app.route('/uploads/<int:proposal_id>/<path:filename>')
def serve_upload(proposal_id, filename):
    # Assuming uploads are stored relative to the dashboard's static folder for now
    # Adjust path if uploads are stored elsewhere
    upload_folder = os.path.join(app.static_folder, 'uploads', str(proposal_id))
    if not os.path.exists(os.path.join(upload_folder, filename)):
         # Fallback to check within dpwhite_app structure if needed
         upload_folder = os.path.join(DPWHITE_APP_DIR, 'uploads', str(proposal_id))
         if not os.path.exists(os.path.join(upload_folder, filename)):
              abort(404)
    return send_from_directory(upload_folder, filename)

# Main route - serve the frontend pages
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_app(path):
    # Handle logout separately if needed, or keep within auth_bp
    # if path == 'logout':
    #     session.clear()
    #     return redirect('/login')

    # If user is not logged in, redirect to login page (except for login itself)
    if 'user_id' not in session and path != 'login':
        return redirect('/login')

    # --- Serve Dashboard Templates --- 
    if path == 'login':
        return render_template('login.html')
    elif path == 'corretor-dashboard':
         # Ensure user is corretor before rendering
         if session.get('user_type') == 'corretor':
              return render_template('corretor_dashboard.html')
         else:
              # Redirect non-corretors away or show error
              return redirect('/login') # Or appropriate dashboard
    elif path == 'admin-dashboard':
         if session.get('user_type') == 'admin':
              return render_template('admin_dashboard.html')
         else:
              return redirect('/login')
    elif path == 'user-dashboard': # Generic user dashboard
         if session.get('user_type') in ['pme', 'adesao', 'individual', 'familiar']:
              return render_template('user_dashboard.html')
         else:
              return redirect('/login')

    # --- Serve dpwhite_app HTML files --- 
    # Check if the requested path corresponds to an HTML file in dpwhite_app
    if path.endswith('.html'):
        file_path = os.path.join(DPWHITE_APP_DIR, path)
        if os.path.exists(file_path):
            # Serve the HTML file directly from the dpwhite_app directory
            return send_from_directory(DPWHITE_APP_DIR, path)

    # --- Fallback / Default --- 
    # If no specific route matched, try to determine based on user type
    user_type = session.get('user_type')
    if user_type == 'corretor':
        return redirect('/corretor-dashboard')
    elif user_type == 'admin':
        return redirect('/admin-dashboard')
    elif user_type in ['pme', 'adesao', 'individual', 'familiar']:
        return redirect('/user-dashboard')
    elif path == '': # Root path for logged-in users without specific type match
         return redirect('/login') # Or a generic landing page

    # If nothing matches, return 404
    abort(404)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)


from flask import Blueprint, request, jsonify, session
from src.models.user import User, db
from src.models.proposal import Proposal, Attachment
from src.routes.auth import login_required, admin_required
import os
from datetime import datetime
from werkzeug.utils import secure_filename

proposals_bp = Blueprint('proposals', __name__)

# Get proposals based on user type
@proposals_bp.route('/api/proposals', methods=['GET'])
@login_required
def get_proposals():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'success': False, 'message': 'Usuário não encontrado'}), 404
    
    # Filter by status if provided
    status = request.args.get('status')
    status_filter = Proposal.status == status if status else True
    
    # Admin can see all proposals, other users only see their own
    if user.user_type == 'admin':
        # For admin, filter by proposal_type if provided
        proposal_type = request.args.get('type')
        type_filter = Proposal.proposal_type == proposal_type if proposal_type else True
        
        proposals = Proposal.query.filter(status_filter, type_filter).order_by(Proposal.created_at.desc()).all()
    else:
        # Regular users only see their own proposals
        proposals = Proposal.query.filter(Proposal.user_id == user_id, status_filter).order_by(Proposal.created_at.desc()).all()
    
    return jsonify({
        'success': True,
        'proposals': [proposal.to_dict() for proposal in proposals]
    })

# Get a specific proposal
@proposals_bp.route('/api/proposals/<int:proposal_id>', methods=['GET'])
@login_required
def get_proposal(proposal_id):
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    proposal = Proposal.query.get(proposal_id)
    
    if not proposal:
        return jsonify({'success': False, 'message': 'Proposta não encontrada'}), 404
    
    # Check if user has access to this proposal
    if user.user_type != 'admin' and proposal.user_id != user_id:
        return jsonify({'success': False, 'message': 'Acesso negado a esta proposta'}), 403
    
    return jsonify({
        'success': True,
        'proposal': proposal.to_dict()
    })

# Create a new proposal
@proposals_bp.route('/api/proposals', methods=['POST'])
@login_required
def create_proposal():
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'success': False, 'message': 'Usuário não encontrado'}), 404
    
    data = request.form.to_dict()
    
    # Validate required fields
    if 'client_name' not in data:
        return jsonify({'success': False, 'message': 'Nome do cliente é obrigatório'}), 400
    
    # Create new proposal
    proposal = Proposal(
        user_id=user_id,
        proposal_type=user.user_type if user.user_type != 'admin' else data.get('proposal_type', 'pme'),
        status='nova',
        client_name=data.get('client_name'),
        client_document=data.get('client_document'),
        client_email=data.get('client_email'),
        client_phone=data.get('client_phone'),
        address_cep=data.get('address_cep'),
        address_street=data.get('address_street'),
        address_number=data.get('address_number'),
        address_complement=data.get('address_complement'),
        address_district=data.get('address_district'),
        address_city=data.get('address_city'),
        address_state=data.get('address_state'),
        plan_name=data.get('plan_name'),
        plan_operator=data.get('plan_operator'),
        plan_modality=data.get('plan_modality'),
        plan_value=data.get('plan_value'),
        plan_coparticipation=data.get('plan_coparticipation'),
        plan_accommodation=data.get('plan_accommodation'),
        plan_validity=data.get('plan_validity')
    )
    
    db.session.add(proposal)
    db.session.commit()
    
    # Handle file uploads
    if 'attachments' in request.files:
        files = request.files.getlist('attachments')
        
        # Create uploads directory if it doesn't exist
        upload_dir = os.path.join(os.getcwd(), 'src', 'static', 'uploads', str(proposal.id))
        os.makedirs(upload_dir, exist_ok=True)
        
        for file in files:
            if file and file.filename:
                filename = secure_filename(file.filename)
                file_path = os.path.join(upload_dir, filename)
                file.save(file_path)
                
                # Create attachment record
                attachment = Attachment(
                    proposal_id=proposal.id,
                    filename=filename,
                    file_path=file_path,
                    file_type=file.content_type,
                    file_size=os.path.getsize(file_path)
                )
                
                db.session.add(attachment)
        
        db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Proposta criada com sucesso',
        'proposal': proposal.to_dict()
    })

# Update proposal status
@proposals_bp.route('/api/proposals/<int:proposal_id>/status', methods=['PUT'])
@login_required
def update_proposal_status(proposal_id):
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    proposal = Proposal.query.get(proposal_id)
    
    if not proposal:
        return jsonify({'success': False, 'message': 'Proposta não encontrada'}), 404
    
    # Check if user has access to this proposal
    if user.user_type != 'admin' and proposal.user_id != user_id:
        return jsonify({'success': False, 'message': 'Acesso negado a esta proposta'}), 403
    
    data = request.get_json()
    
    if not data or 'status' not in data:
        return jsonify({'success': False, 'message': 'Status não fornecido'}), 400
    
    # Validate status
    valid_statuses = ['nova', 'pendente', 'enviada', 'declinada']
    if data['status'] not in valid_statuses:
        return jsonify({'success': False, 'message': 'Status inválido'}), 400
    
    proposal.status = data['status']
    proposal.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Status da proposta atualizado com sucesso',
        'proposal': proposal.to_dict()
    })

# Delete a proposal
@proposals_bp.route('/api/proposals/<int:proposal_id>', methods=['DELETE'])
@login_required
def delete_proposal(proposal_id):
    user_id = session.get('user_id')
    user = User.query.get(user_id)
    
    proposal = Proposal.query.get(proposal_id)
    
    if not proposal:
        return jsonify({'success': False, 'message': 'Proposta não encontrada'}), 404
    
    # Check if user has access to this proposal
    if user.user_type != 'admin' and proposal.user_id != user_id:
        return jsonify({'success': False, 'message': 'Acesso negado a esta proposta'}), 403
    
    # Delete attachments files
    for attachment in proposal.attachments:
        if os.path.exists(attachment.file_path):
            os.remove(attachment.file_path)
    
    # Delete proposal (will cascade delete attachments records)
    db.session.delete(proposal)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Proposta excluída com sucesso'
    })

from flask import Blueprint, request, jsonify, session, redirect, url_for, render_template
from src.models.user import User, db
from functools import wraps

auth_bp = Blueprint('auth', __name__)

# Authentication decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Autenticação necessária'}), 401
        return f(*args, **kwargs)
    return decorated_function

# Admin access decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Autenticação necessária'}), 401
        
        user = User.query.get(session['user_id'])
        if not user or user.user_type != 'admin':
            return jsonify({'success': False, 'message': 'Acesso restrito a administradores'}), 403
            
        return f(*args, **kwargs)
    return decorated_function

# Routes
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or 'email' not in data or 'password' not in data:
        return jsonify({'success': False, 'message': 'Dados de login incompletos'}), 400
    
    email = data['email']
    password = data['password']
    
    user = User.query.filter_by(email=email).first()
    
    if not user or not user.check_password(password):
        return jsonify({'success': False, 'message': 'Email ou senha inválidos'}), 401
    
    # Store user info in session
    session['user_id'] = user.id
    session['user_type'] = user.user_type
    session['user_email'] = user.email
    
    # Determine redirect URL based on user type
    redirect_url = '/dashboard'
    if user.user_type == 'corretor':
        redirect_url = '/corretor-dashboard'
    elif user.user_type == 'admin':
        redirect_url = '/admin-dashboard'
    
    return jsonify({
        'success': True, 
        'message': 'Login realizado com sucesso',
        'redirect': redirect_url,
        'user': {
            'id': user.id,
            'email': user.email,
            'user_type': user.user_type,
            'name': user.name
        }
    })

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logout realizado com sucesso'})

@auth_bp.route('/check-auth', methods=['GET'])
def check_auth():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            return jsonify({
                'success': True,
                'authenticated': True,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'user_type': user.user_type,
                    'name': user.name
                }
            })
    
    return jsonify({'success': True, 'authenticated': False})

# Initialize default users
@auth_bp.route('/corretor-dashboard')
def corretor_dashboard():
    """Render the corretor dashboard page"""
    return render_template('corretor_dashboard.html')

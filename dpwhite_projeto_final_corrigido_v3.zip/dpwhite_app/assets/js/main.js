document.addEventListener('DOMContentLoaded', function() {
  // Seleção de cards (operadoras, opções, etc)
  document.querySelectorAll('.option-card, .operadora-card').forEach(card => {
    card.addEventListener('click', function() {
      // Remove a classe 'selected' de todos os cards do mesmo grupo
      const parentElement = this.parentElement;
      parentElement.querySelectorAll('.option-card, .operadora-card').forEach(c => {
        c.classList.remove('selected');
      });
      
      // Adiciona a classe 'selected' ao card clicado
      this.classList.add('selected');
      
      // Salva a operadora selecionada no localStorage
      if (this.classList.contains('operadora-card')) {
        const operadoraNome = this.getAttribute('data-name');
        const operadoraCodigo = this.getAttribute('data-code');
        localStorage.setItem('operadoraNome', operadoraNome);
        localStorage.setItem('operadoraCodigo', operadoraCodigo);
      }
      
      // Habilita o botão de continuar se houver um com o atributo data-requires-selection
      const continueButton = document.querySelector('button[data-requires-selection="true"]');
      if (continueButton) {
        continueButton.disabled = false;
      }
    });
  });
  
  // Navegação entre páginas
  document.querySelectorAll('[data-navigate]').forEach(button => {
    button.addEventListener('click', function() {
      // Verifica se o botão requer validação
      if (this.hasAttribute('data-validate') && this.getAttribute('data-validate') === 'true') {
        // Aqui você pode adicionar validações específicas
        const form = document.querySelector('form');
        if (form && !form.checkValidity()) {
          form.reportValidity();
          return;
        }
      }
      
      // Navega para a página especificada, com lógica condicional para PME vs PF
      let targetPage = this.getAttribute('data-navigate');
      
      // Verifica se estamos na página de operadora e precisamos direcionar para fluxos diferentes
      if (window.location.pathname.includes('operadora.html')) {
        const tipoProposta = localStorage.getItem('tipoProposta');
        
        if (tipoProposta === 'PME') {
          // Redireciona para o fluxo PME
          targetPage = 'detalhes-contrato-pme.html';
        } else if (tipoProposta === 'PF') {
          // Redireciona para o fluxo PF
          targetPage = 'plano-pf.html';
        }
      }
      
      window.location.href = targetPage;
    });
  });
  
  // Paginação de operadoras
  const setupPagination = () => {
    const paginationButtons = document.querySelectorAll('.pagination-button');
    if (paginationButtons.length === 0) return;
    
    paginationButtons.forEach(button => {
      button.addEventListener('click', function() {
        if (this.disabled) return;
        
        const currentPage = document.querySelector('.pagination-button.active');
        if (!currentPage) return;
        
        const currentPageNum = parseInt(currentPage.getAttribute('data-page'));
        let targetPage;
        
        if (this.getAttribute('data-page') === 'prev') {
          targetPage = currentPageNum - 1;
        } else if (this.getAttribute('data-page') === 'next') {
          targetPage = currentPageNum + 1;
        } else {
          targetPage = parseInt(this.getAttribute('data-page'));
        }
        
        // Esconde todas as páginas de operadoras
        document.querySelectorAll('.operadoras-grid').forEach(grid => {
          grid.style.display = 'none';
        });
        
        // Mostra a página alvo
        document.getElementById(`operadoras-page-${targetPage}`).style.display = 'grid';
        
        // Atualiza os botões de paginação
        document.querySelector('.pagination-button.active').classList.remove('active');
        document.querySelector(`.pagination-button[data-page="${targetPage}"]`).classList.add('active');
        
        // Habilita/desabilita botões de navegação
        const maxPage = 4; // Número total de páginas
        document.querySelector('.pagination-button[data-page="prev"]').disabled = (targetPage === 1);
        document.querySelector('.pagination-button[data-page="next"]').disabled = (targetPage === maxPage);
      });
    });
  };
  
  setupPagination();
  
  // Busca de operadoras
  const searchInput = document.getElementById('operadora-search');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase();
      document.querySelectorAll('.operadora-card').forEach(card => {
        const operadoraName = card.getAttribute('data-name').toLowerCase();
        if (operadoraName.includes(searchTerm)) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  }
  
  // Botão continuar na página de operadoras
  const continuarBtn = document.getElementById('btn-continuar');
  if (continuarBtn && window.location.pathname.includes('operadora.html')) {
    continuarBtn.addEventListener('click', function() {
      const operadoraSelecionada = document.querySelector('.operadora-card.selected');
      if (!operadoraSelecionada) {
        alert('Por favor, selecione uma operadora para continuar.');
        return;
      }
      
      const operadoraNome = operadoraSelecionada.getAttribute('data-name');
      const operadoraCodigo = operadoraSelecionada.getAttribute('data-code');
      localStorage.setItem('operadoraNome', operadoraNome);
      localStorage.setItem('operadoraCodigo', operadoraCodigo);
      
      // Redireciona com base no tipo de proposta
      const tipoProposta = localStorage.getItem('tipoProposta');
      if (tipoProposta === 'PME') {
        window.location.href = 'detalhes-contrato-pme.html';
      } else if (tipoProposta === 'PF') {
        window.location.href = 'plano-pf.html';
      }
    });
  }
});

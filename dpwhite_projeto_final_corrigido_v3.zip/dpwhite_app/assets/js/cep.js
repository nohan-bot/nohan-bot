/**
 * Validação de CEP e preenchimento automático de endereço
 * DP White VH Seguros
 */

// Função para buscar endereço por CEP
async function buscarEnderecoPorCEP(cep, loadingElementId, errorElementId) {
  const loadingElement = document.getElementById(loadingElementId);
  const errorElement = document.getElementById(errorElementId);

  try {
    // Limpa mensagens anteriores
    if (loadingElement) loadingElement.style.display = 'none';
    if (errorElement) errorElement.style.display = 'none';

    // Remove caracteres não numéricos
    cep = cep.replace(/\D/g, '');

    // Verifica se o CEP tem 8 dígitos
    if (cep.length !== 8) {
      throw new Error('CEP inválido (deve ter 8 dígitos)');
    }

    // Exibe mensagem de carregamento
    if (loadingElement) loadingElement.style.display = 'block';

    // Busca o endereço na API ViaCEP
    const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);

    // Oculta mensagem de carregamento
    if (loadingElement) loadingElement.style.display = 'none';

    // Verifica se a resposta foi bem-sucedida
    if (!response.ok) {
      throw new Error(`Erro HTTP: ${response.status}`);
    }

    // Converte a resposta para JSON
    const data = await response.json();

    // Verifica se o CEP foi encontrado
    if (data.erro) {
      throw new Error('CEP não encontrado');
    }

    // Preenche os campos do formulário automaticamente
    const logradouroInput = document.getElementById('titular-logradouro');
    const bairroInput = document.getElementById('titular-bairro');
    const cidadeInput = document.getElementById('titular-cidade');
    const estadoInput = document.getElementById('titular-estado');

    if (logradouroInput) logradouroInput.value = data.logradouro;
    if (bairroInput) bairroInput.value = data.bairro;
    if (cidadeInput) cidadeInput.value = data.localidade;
    if (estadoInput) estadoInput.value = data.uf;

    // Retorna os dados do endereço
    return {
      logradouro: data.logradouro,
      bairro: data.bairro,
      cidade: data.localidade,
      uf: data.uf
    };
  } catch (error) {
    // Oculta mensagem de carregamento
    if (loadingElement) loadingElement.style.display = 'none';

    // Exibe mensagem de erro
    if (errorElement) {
        errorElement.textContent = `Erro: ${error.message}`;
        errorElement.style.display = 'block';
    }

    // Registra o erro no console
    console.error('Erro ao buscar endereço:', error);

    // Retorna null em caso de erro
    return null;
  }
}

// Adiciona o evento de clique no botão de busca CEP
document.addEventListener('DOMContentLoaded', function() {
  const btnBuscarCep = document.getElementById('btn-buscar-cep');
  const cepInput = document.getElementById('titular-cep');

  if (btnBuscarCep && cepInput) {
    btnBuscarCep.addEventListener('click', async function() {
      await buscarEnderecoPorCEP(cepInput.value, 'loading-cep', 'cep-error');
    });
  }
});

// Função para preencher os campos de endereço
function preencherCamposEndereco(endereco, logradouroId, bairroId, cidadeId, ufId, numeroId) {
  if (!endereco) return;

  // Preenche os campos de endereço
  const logradouroInput = document.getElementById(logradouroId);
  const bairroInput = document.getElementById(bairroId);
  const cidadeInput = document.getElementById(cidadeId);
  const ufInput = document.getElementById(ufId);
  const numeroInput = document.getElementById(numeroId);

  if (logradouroInput) logradouroInput.value = endereco.logradouro || '';
  if (bairroInput) bairroInput.value = endereco.bairro || '';
  if (cidadeInput) cidadeInput.value = endereco.cidade || '';
  if (ufInput) ufInput.value = endereco.uf || '';

  // Foca no campo de número se o endereço foi preenchido
  if (numeroInput && endereco.logradouro) {
      numeroInput.focus();
  }
}

// Exporta as funções para uso em outros arquivos
window.cepUtils = {
  buscarEnderecoPorCEP,
  preencherCamposEndereco
};

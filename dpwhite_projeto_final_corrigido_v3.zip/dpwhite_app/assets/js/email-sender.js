/**
 * Módulo para envio de email com as informações da proposta via backend PHP
 */

// Adiciona a função ao escopo global ou a um namespace (ex: window.emailSender)
window.emailSender = {
    enviarPropostaPorEmail: async function(dadosProposta) { // Aceita dados como argumento
        console.log("Iniciando envio da proposta para o backend...");
        const loadingOverlay = document.querySelector(".loading-overlay");
        if (loadingOverlay) loadingOverlay.style.display = "flex"; // Show loading

        try {
            // 1. Dados da proposta já recebidos como argumento
            console.log("Dados recebidos para envio:", dadosProposta);

            // 2. Preparar FormData
            const formData = new FormData();
            formData.append("dadosProposta", JSON.stringify(dadosProposta));

            // 3. Anexar arquivos (LÓGICA DE ANEXOS AINDA PRECISA SER DEFINIDA/IMPLEMENTADA)
            // Esta parte ainda é uma suposição e depende de como os arquivos
            // são gerenciados nas etapas anteriores. Se os arquivos precisarem ser
            // enviados, eles devem ser adicionados ao formData aqui.
            // Exemplo: Se os File objects estão disponíveis em uma variável global window.uploadedFiles
            // if (window.uploadedFiles) {
            //     for (const key in window.uploadedFiles) {
            //         if (window.uploadedFiles[key] instanceof File) {
            //             formData.append(key, window.uploadedFiles[key], window.uploadedFiles[key].name);
            //             console.log(`Anexando arquivo: ${key} - ${window.uploadedFiles[key].name}`);
            //         }
            //     }
            // }
            // Por enquanto, enviaremos sem arquivos para testar a comunicação e o PHP.
            // O script PHP atual já tenta ler de $_FILES, então precisamos garantir que
            // o JS envie os arquivos corretamente se eles forem necessários.
            // Vamos verificar se há referências de arquivos no localStorage e tentar anexá-los
            // Assumindo que as páginas anteriores armazenaram os File objects em algum lugar acessível
            // ou que precisamos buscar os inputs de arquivo (menos provável na página de resumo).

            // Tentativa de buscar arquivos de inputs (exemplo, pode não se aplicar aqui)
            // const fileInputs = document.querySelectorAll("input[type=file]");
            // fileInputs.forEach(input => {
            //     if (input.files.length > 0) {
            //         formData.append(input.name || input.id, input.files[0], input.files[0].name);
            //         console.log(`Anexando arquivo do input ${input.name || input.id}: ${input.files[0].name}`);
            //     }
            // });

            // Tentativa de buscar referências de arquivos no localStorage (precisaria dos File objects)
            Object.keys(dadosProposta).forEach(key => {
                if (key.startsWith("arquivo-") && dadosProposta[key]) {
                    // Precisamos do File object real aqui. Se dadosProposta[key] for apenas o nome,
                    // não podemos anexar. Se for um DataURL, precisamos converter para Blob/File.
                    // Esta parte precisa ser validada com base na implementação das páginas de upload.
                    console.warn(`Referência de arquivo encontrada (${key}), mas a lógica de anexo real ainda precisa ser implementada.`);
                }
            });


            // 4. Enviar para o backend
            console.log("Enviando FormData para api/enviar_proposta.php");
            const response = await fetch("api/enviar_proposta.php", {
                method: "POST",
                body: formData
            });

            console.log("Resposta recebida do backend:", response);

            // Ler o corpo da resposta como texto para ver o debug do PHP
            const responseBody = await response.text();
            console.log("Corpo da resposta do backend:", responseBody);

            if (!response.ok) {
                 // Tentar interpretar como JSON, senão usar o texto bruto
                 let errorMsg = `Erro HTTP: ${response.status}`;
                 try {
                     const errorJson = JSON.parse(responseBody);
                     errorMsg = errorJson.message || responseBody;
                 } catch (e) {
                     errorMsg = responseBody || errorMsg; // Usar o texto se não for JSON
                 }
                 throw new Error(errorMsg);
            }

            // 5. Processar a resposta JSON (se a resposta foi OK)
            let resultado;
            try {
                 resultado = JSON.parse(responseBody);
            } catch (e) {
                 console.error("Erro ao fazer parse da resposta JSON:", e);
                 console.error("Resposta recebida:", responseBody);
                 throw new Error("Resposta inválida recebida do servidor.");
            }

            console.log("Resultado JSON do backend:", resultado);

            if (loadingOverlay) loadingOverlay.style.display = "none"; // Hide loading
            return resultado; // Deve ser { success: boolean, message: string }

        } catch (error) {
            console.error("Erro na função enviarPropostaPorEmail:", error);
            if (loadingOverlay) loadingOverlay.style.display = "none"; // Hide loading
            return { success: false, message: error.message || "Erro de comunicação ao enviar proposta." };
        }
    }
};

console.log("Módulo email-sender.js carregado e função anexada a window.emailSender.");


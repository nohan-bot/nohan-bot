-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS dpwhite_db;
USE dpwhite_db;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE,
    token_recuperacao VARCHAR(100),
    token_expiracao DATETIME
);

-- Tabela de sessões
CREATE TABLE IF NOT EXISTS sessoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    token VARCHAR(255) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_expiracao DATETIME NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de tentativas de login
CREATE TABLE IF NOT EXISTS tentativas_login (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    tentativas INT DEFAULT 1,
    ultima_tentativa TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    bloqueado BOOLEAN DEFAULT FALSE
);

-- Índices para melhor performance
CREATE INDEX idx_email ON usuarios(email);
CREATE INDEX idx_token ON sessoes(token);
CREATE INDEX idx_tentativas_email ON tentativas_login(email);

-- Configurações de segurança
ALTER TABLE usuarios
    ADD CONSTRAINT chk_email CHECK (email REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    ADD CONSTRAINT chk_senha CHECK (LENGTH(senha_hash) >= 60);

-- Comentários das tabelas
COMMENT ON TABLE usuarios IS 'Armazena informações dos usuários do sistema';
COMMENT ON TABLE sessoes IS 'Controle de sessões ativas dos usuários';
COMMENT ON TABLE tentativas_login IS 'Registro de tentativas de login para prevenção de força bruta';